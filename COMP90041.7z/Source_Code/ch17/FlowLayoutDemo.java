
public class FlowLayoutDemo
{
    public static void main(String[] args)
    {
        FlowLayoutJFrame gui = new FlowLayoutJFrame();
        gui.setVisible(true);
    }
}
