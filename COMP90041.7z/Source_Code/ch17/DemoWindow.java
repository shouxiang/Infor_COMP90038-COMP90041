
public class DemoWindow
{
    public static void main(String[] args) 
    {
        FirstWindow w = new FirstWindow( );
        w.setVisible(true);
    }
}
