
public class BorderLayoutDemo
{
    public static void main(String[] args) 
    {
        BorderLayoutJFrame gui = new BorderLayoutJFrame( );
        gui.setVisible(true);
    }
}
