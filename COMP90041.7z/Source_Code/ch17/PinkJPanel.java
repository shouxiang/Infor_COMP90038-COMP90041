
import javax.swing.JPanel;
import java.awt.Color;

public class PinkJPanel extends JPanel
{
    public PinkJPanel( )
    {
        setBackground(Color.PINK);
    }
}
