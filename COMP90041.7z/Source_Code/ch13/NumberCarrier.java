

public interface NumberCarrier
{
    public void setNumber(int value); 
    public int getNumber( ); 
}
