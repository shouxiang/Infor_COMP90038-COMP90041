
public class GradeBookDemo
{
     public static void main(String[] args) 
     {
         GradeBook book = new GradeBook( );
         book.display( );
     }
 }
 