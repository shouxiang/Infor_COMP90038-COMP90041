
public class DateThirdTryDemo
{
   public static void main(String[] args)
   {
        DateThirdTry date = new DateThirdTry(  );
        int year = 1882;
        date.setDate(6, 17, year);
        date.writeOutput(  );
     }
}
